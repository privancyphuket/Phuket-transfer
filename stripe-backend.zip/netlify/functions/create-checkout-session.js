// Netlify Function: create-checkout-session.js
// Deploy path: netlify/functions/create-checkout-session.js
//
// This is the missing "backend" piece. The website (index.html) never touches
// the card number — it calls this function, which talks to Stripe using your
// SECRET key (kept safely on the server, never in the browser), and Stripe
// hosts the actual card-entry page.

const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const body = JSON.parse(event.body);
    const {
      route, vehicle, trip, amount_thb,
      passengers, flight, date, time, pickup, dropoff, notes,
      name, phone, email
    } = body;

    // --- basic server-side validation (never trust the browser) ---
    if (!route || !vehicle || !amount_thb || amount_thb < 1) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Missing or invalid booking details' }) };
    }

    const siteUrl = process.env.SITE_URL || 'https://your-site.netlify.app';

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'],
      customer_email: email || undefined,
      line_items: [{
        price_data: {
          currency: 'thb',
          unit_amount: Math.round(amount_thb) * 100, // Stripe uses satang (smallest unit)
          product_data: {
            name: `Phuket Airport Transfer — ${vehicle} — ${route} (${trip === 'round' ? 'Round trip' : 'One way'})`,
            description: `Pickup: ${pickup || 'Phuket Airport'} | Drop-off: ${dropoff || route} | ${date || ''} ${time || ''}`.trim(),
          },
        },
        quantity: 1,
      }],
      metadata: {
        route, vehicle, trip, passengers: String(passengers || ''), flight: flight || '',
        date: date || '', time: time || '', pickup: pickup || '', dropoff: dropoff || '',
        notes: notes || '', name: name || '', phone: phone || ''
      },
      success_url: `${siteUrl}/booking-success.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${siteUrl}/#booking`,
    });

    return {
      statusCode: 200,
      body: JSON.stringify({ id: session.id, url: session.url }),
    };
  } catch (err) {
    console.error(err);
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
